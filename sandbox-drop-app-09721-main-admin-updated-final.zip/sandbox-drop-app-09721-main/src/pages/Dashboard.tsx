import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Copy, CheckCircle2, AlertCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import FeatureCard from "@/components/FeatureCard";
import LiveChat from "@/components/LiveChat";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useBookingProgress } from "@/hooks/useBookingProgress";
import TransactionsChart from "@/components/TransactionsChart";

const PACKAGES_INFO = [
  { level: "beginner", name: "Beginner", payout: 7500 },
  { level: "standard", name: "Standard", payout: 11250 },
  { level: "expert", name: "Expert", payout: 18750 },
];

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [wallet, setWallet] = useState<any>(null);
  const [totalWithdrawn, setTotalWithdrawn] = useState(0);
  const [activeBookings, setActiveBookings] = useState<string[]>([]);
  const navigate = useNavigate();
  const { user } = useAuth();
  const referralLink = "ent.pantheonsite.io/register/?ref=ally";
  
  // Enable automatic booking progress updates
  useBookingProgress(user?.id);

  useEffect(() => {
    if (user) {
      checkIfAdmin();
      fetchUserData();
    }
  }, [user]);

  const checkIfAdmin = async () => {
    try {
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user?.id);
      
      const isAdmin = roles?.some(r => r.role === 'admin' || r.role === 'super_admin');
      
      if (isAdmin) {
        navigate('/admin-dashboard');
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  };

  const fetchUserData = async () => {
    try {
      const client = supabase as any;
      const { data: profileData } = await client
        .from("profiles")
        .select("*")
        .eq("id", user?.id)
        .maybeSingle();

      const { data: walletData } = await client
        .from("wallets")
        .select("*")
        .eq("user_id", user?.id)
        .maybeSingle();

      // Fetch active bookings
      const { data: bookingsData } = await client
        .from("bookings")
        .select("*")
        .eq("user_id", user?.id)
        .eq("is_paid", true);

      if (bookingsData) {
        const activeLevels = bookingsData.map((b: any) => b.level);
        setActiveBookings(activeLevels);
      }

      // Fetch total withdrawn
      const { data: transactionsData } = await client
        .from("transactions")
        .select("amount")
        .eq("user_id", user?.id)
        .eq("type", "withdrawal")
        .eq("status", "completed");

      if (transactionsData) {
        const withdrawn = transactionsData.reduce((sum: number, txn: any) => {
          return sum + parseFloat(txn.amount || 0);
        }, 0);
        setTotalWithdrawn(withdrawn);
      }

      setProfile(profileData);
      setWallet(walletData);
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied!`);
  };

  const handleTopUp = () => {
    navigate("/deposit");
  };

  const handleWithdraw = () => {
    navigate("/withdraw");
  };

  return (
    <div className="flex flex-col min-h-screen w-full">
      <Header
        showLogo
        showMenu
        onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)}
        backTo="/login"
      />

      <div className="flex flex-1 overflow-hidden w-full">
        <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <main className="flex-1 overflow-y-auto p-5 md:p-8 lg:p-10">
          <div className="max-w-3xl mx-auto space-y-5">
            {/* Status Badges */}
            <div className="flex gap-3 flex-wrap justify-center mb-4">
              {profile?.is_active ? (
                <Badge className="bg-success hover:bg-success text-success-foreground gap-2 px-4 py-2 text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  Active
                </Badge>
              ) : (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => navigate("/manual-payment")}
                  className="gap-2 px-4 py-2 text-sm"
                >
                  <XCircle className="w-4 h-4" />
                  Inactive - Click to Activate
                </Button>
              )}
              {profile?.is_verified ? (
                <Badge className="bg-blue-500 hover:bg-blue-600 text-white gap-2 px-4 py-2 text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  Verified ✓
                </Badge>
              ) : (
                <Badge variant="outline" className="gap-2 px-4 py-2 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  Not Verified
                </Badge>
              )}
            </div>

            {/* Welcome Message */}
            <section className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl p-6 shadow-sm border border-primary/20">
              <div className="text-center space-y-2">
                <h1 className="text-2xl md:text-3xl font-bold">
                  Welcome to Dropship UK! 🇬🇧
                </h1>
                <p className="text-sm text-muted-foreground">
                  Hello, {profile?.full_name || user?.email}!
                </p>
                <p className="text-xs text-muted-foreground">
                  You are in your financial growth.
                </p>
              </div>
            </section>

            {/* Wallet Card */}
            <section className="bg-card rounded-xl p-6 shadow-sm border-l-4 border-primary">
              <div className="flex items-center gap-2 text-primary font-semibold mb-4">
                <span className="text-xl">💳</span>
                <span>Total Balance</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                For API & Subscriptions
              </p>
              <div className="text-3xl md:text-4xl font-bold mb-4">
                ${(wallet?.balance / 130)?.toFixed(2) || "0.00"}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button onClick={handleTopUp} className="flex-1">
                  Top Up ↑
                </Button>
                <Button onClick={handleWithdraw} variant="destructive" className="flex-1">
                  Withdraw ↑
                </Button>
              </div>
            </section>

            {/* Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FeatureCard 
                icon="💳" 
                title="Payment Channels" 
                subtitle="Deposit & Withdraw" 
                onClick={() => navigate("/deposit")}
              />
              <FeatureCard 
                icon="📦" 
                title="Running Bookings" 
                subtitle="View Orders" 
                onClick={() => navigate("/running-bookings")}
              />
              <FeatureCard 
                icon="👥" 
                title="Refer & Earn" 
                subtitle="Share & Earn" 
                onClick={() => navigate("/refer-and-earn")}
              />
              <FeatureCard 
                icon="🚚" 
                title="Dropshipping" 
                subtitle="Start Earning" 
                onClick={() => navigate("/dropshipping")}
              />
            </div>

            {/* Transactions Chart */}
            <TransactionsChart userId={user?.id} />

            {/* Referral Card */}
            <section className="bg-card rounded-xl p-6 shadow-sm border-l-4 border-primary">
              <div className="flex items-center gap-2 text-primary font-semibold mb-4">
                <span className="text-xl">🔗</span>
                <span>Here's your Referral Link</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Get paid commission when you share your link with your friends and they
                book with one simple link.
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                Share your referral link below with your friends:
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={referralLink}
                  readOnly
                  className="flex-1 px-4 py-2 bg-secondary border border-border rounded-lg text-sm"
                />
                <Button onClick={() => handleCopy(referralLink, "Referral link")} size="sm" variant="outline">
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </section>

            {/* Bookings Summary Table */}
            <section className="bg-card rounded-xl p-6 shadow-sm border-l-4 border-primary">
              <h3 className="text-xl font-bold mb-4">📊 Bookings Summary</h3>
              
              <div className="mb-6 p-4 bg-primary/5 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Total Amount Withdrawn</p>
                <p className="text-3xl font-bold text-primary">
                  ${(totalWithdrawn / 130).toFixed(2)}
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-2 font-semibold">Booking</th>
                      <th className="text-left py-3 px-2 font-semibold">Payout</th>
                      <th className="text-left py-3 px-2 font-semibold">Condition</th>
                    </tr>
                  </thead>
                  <tbody>
                    {PACKAGES_INFO.map((pkg) => {
                      const isActive = activeBookings.includes(pkg.level);
                      return (
                        <tr key={pkg.level} className="border-b hover:bg-secondary/50 transition-colors">
                          <td className="py-4 px-2 font-medium">{pkg.name}</td>
                          <td className="py-4 px-2">${(pkg.payout / 130).toFixed(2)}</td>
                          <td className="py-4 px-2">
                            {isActive ? (
                              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold bg-success/10 text-success">
                                <CheckCircle2 className="w-4 h-4" />
                                Active
                              </span>
                            ) : (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => navigate("/manual-payment")}
                                className="inline-flex items-center gap-1 text-xs border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                              >
                                <XCircle className="w-4 h-4" />
                                Inactive - Click to Activate
                              </Button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </main>
      </div>

      <LiveChat />
    </div>
  );
};

export default Dashboard;
