import { useState } from "react";
import { Link as LinkIcon, Copy, Users, TrendingUp } from "lucide-react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const ReferAndEarn = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const referralLink = "ent.pantheonsite.io/register/?ref=ally";

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    toast.success("Referral link copied!");
  };

  return (
    <div className="flex flex-col min-h-screen w-full">
      <Header
        showLogo
        showMenu
        onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)}
        backTo="/dashboard"
      />

      <div className="flex flex-1 overflow-hidden w-full">
        <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <main className="flex-1 overflow-y-auto p-5 md:p-8 lg:p-10">
          <div className="max-w-3xl mx-auto space-y-5">
            <section className="bg-card rounded-xl p-4 sm:p-6 shadow-sm border-l-4 border-primary">
              <div className="flex items-center gap-2 text-primary font-semibold mb-3 sm:mb-4">
                <LinkIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                <span className="text-sm sm:text-base">Your Referral Link</span>
              </div>
              <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4">
                Share your unique referral link with friends and earn commission when they book.
              </p>
              <div className="flex gap-2">
                <Input
                  type="text"
                  value={referralLink}
                  readOnly
                  className="bg-secondary text-xs sm:text-sm"
                />
                <Button onClick={handleCopy} size="sm" variant="outline" className="flex-shrink-0">
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </section>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
              <section className="bg-card rounded-xl p-4 sm:p-6 shadow-sm border-l-4 border-primary">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  <span className="text-xs sm:text-sm text-muted-foreground">Total Referrals</span>
                </div>
                <div className="text-2xl sm:text-3xl font-bold">0</div>
              </section>

              <section className="bg-card rounded-xl p-4 sm:p-6 shadow-sm border-l-4 border-primary">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  <span className="text-xs sm:text-sm text-muted-foreground">Active Referrals</span>
                </div>
                <div className="text-2xl sm:text-3xl font-bold">0</div>
              </section>

              <section className="bg-card rounded-xl p-4 sm:p-6 shadow-sm border-l-4 border-primary">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  <span className="text-xs sm:text-sm text-muted-foreground">Total Earned</span>
                </div>
                <div className="text-2xl sm:text-3xl font-bold">KES 0</div>
              </section>
            </div>

            <section className="bg-card rounded-xl p-4 sm:p-6 shadow-sm border-l-4 border-primary">
              <h3 className="font-semibold mb-3 sm:mb-4 text-sm sm:text-base">How It Works</h3>
              <div className="space-y-3 text-xs sm:text-sm text-muted-foreground">
                <div className="flex gap-2 sm:gap-3">
                  <span className="flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-bold">1</span>
                  <p>Share your unique referral link with friends and family</p>
                </div>
                <div className="flex gap-2 sm:gap-3">
                  <span className="flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-bold">2</span>
                  <p>They sign up and make their first booking using your link</p>
                </div>
                <div className="flex gap-2 sm:gap-3">
                  <span className="flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-bold">3</span>
                  <p>You earn 5% commission on every booking they make</p>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ReferAndEarn;
