import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import Header from "@/components/Header";
import Logo from "@/components/Logo";
import FormInput from "@/components/FormInput";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";

const Login = () => {
  const navigate = useNavigate();
  const { signIn, user } = useAuth();
  const [searchParams] = useSearchParams();
  const roleParam = searchParams.get("role");
  const isAdminLogin = roleParam === "admin";
  
  const [formData, setFormData] = useState({
    emailUsername: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Don't redirect here - let AuthContext handle it
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.emailUsername || !formData.password) {
      toast.error("Please fill in all fields!");
      return;
    }

    setLoading(true);
    try {
      const { error } = await signIn(formData.emailUsername, formData.password);
      
      if (error) {
        toast.error(error.message || "Login failed!");
      } else {
        toast.success("Login successful!");
      }
    } catch (err: any) {
      toast.error(err.message || "An error occurred during login");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Login - DropshipUK" backTo="/" />

      <main className="flex-1 flex flex-col items-center px-6 py-8">
        <Logo />
        
        <div className="flex items-center gap-2 mt-8 mb-2">
          <h2 className="text-2xl font-semibold">Welcome Back!</h2>
          {isAdminLogin && <Badge variant="destructive">Admin</Badge>}
        </div>
        <p className="text-muted-foreground mb-8">
          {isAdminLogin ? "Admin login - authorized personnel only" : "Please sign in to your account"}
        </p>

        <form onSubmit={handleSubmit} className="w-full flex flex-col items-center space-y-5">
          <FormInput
            label="Username or Email"
            type="text"
            placeholder="E-mail / Username"
            value={formData.emailUsername}
            onChange={(e) => setFormData({ ...formData, emailUsername: e.target.value })}
            required
          />

          <FormInput
            label="Password"
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            required
          />

          <Button type="submit" className="w-full max-w-sm mt-4" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </Button>
        </form>

        <div className="flex items-center w-full max-w-sm my-6">
          <div className="flex-1 h-px bg-border" />
          <span className="px-4 text-sm text-muted-foreground">Or</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <button
          onClick={() => navigate("/register")}
          className="text-primary font-medium hover:underline"
        >
          Create Account
        </button>
      </main>
    </div>
  );
};

export default Login;
