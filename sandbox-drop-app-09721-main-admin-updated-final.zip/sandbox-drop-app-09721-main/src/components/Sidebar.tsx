import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import {
  Home,
  Upload,
  Users,
  Download,
  User,
  Link as LinkIcon,
  Phone,
  Rocket,
  Package,
  FileText,
  Lock,
  IdCard,
  LogOut,
  Award,
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const navigate = useNavigate();
  const { signOut } = useAuth();

  const handleNavigation = (path: string) => {
    navigate(path);
    onClose();
  };

  const handleLogout = async () => {
    await signOut();
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <nav
        className={`
          fixed lg:static top-0 left-0 h-full w-72 bg-sidebar-background border-r border-sidebar-border z-50
          transform transition-transform duration-300 lg:transform-none overflow-y-auto
          ${isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        <div className="py-5">
          <div className="mb-6">
            <button
              onClick={() => handleNavigation("/dashboard")}
              className="w-full flex items-center px-4 py-3 text-sm font-medium text-sidebar-primary hover:bg-sidebar-accent transition-colors"
            >
              <Home className="w-4 h-4 mr-3" />
              Dashboard
            </button>
          </div>

          <div className="mb-6">
            <div className="px-4 pb-2 text-sm font-semibold text-sidebar-foreground border-b border-sidebar-border">
              Account
            </div>
            <SidebarItem 
              icon={<Upload />} 
              label="Deposit" 
              hasArrow 
              onClick={() => handleNavigation("/deposit")}
            />
            <SidebarItem 
              icon={<Users />} 
              label="Pay For Downline"
              onClick={() => handleNavigation("/pay-for-downline")}
            />
            <SidebarItem 
              icon={<Download />} 
              label="Withdraw"
              onClick={() => handleNavigation("/withdraw")}
            />
            <SidebarItem 
              icon={<User />} 
              label="Your Account"
              onClick={() => handleNavigation("/account")}
            />
            <SidebarItem 
              icon={<LinkIcon />} 
              label="Refer And Earn"
              onClick={() => handleNavigation("/refer-and-earn")}
            />
            <SidebarItem 
              icon={<Phone />} 
              label="Customer Care"
              onClick={() => window.open("mailto:dropshipment.ecommerce@gmail.com", "_blank")}
            />
          </div>

          <div className="mb-6">
            <div className="px-4 pb-2 text-sm font-semibold text-sidebar-foreground border-b border-sidebar-border">
              Dropshipping 🇬🇧
            </div>
            <SidebarItem 
              icon={<Package />} 
              label="Dropshipping Dashboard"
              onClick={() => handleNavigation("/dropshipping")}
            />
            <SidebarItem 
              icon={<Rocket />} 
              label="Start Application"
              onClick={() => handleNavigation("/start-dropshipping")}
            />
            <SidebarItem 
              icon={<Package />} 
              label="Running Bookings"
              onClick={() => handleNavigation("/running-bookings")}
            />
          </div>

          <div className="mb-6">
            <div className="px-4 pb-2 text-sm font-semibold text-sidebar-foreground border-b border-sidebar-border">
              Premium
            </div>
            <SidebarItem 
              icon={<Award />} 
              label="Premium Withdraw Codes"
              onClick={() => handleNavigation("/premium-codes")}
            />
          </div>

          <div className="mb-6">
            <div className="px-4 pb-2 text-sm font-semibold text-sidebar-foreground border-b border-sidebar-border">
              Others
            </div>
            <SidebarItem 
              icon={<FileText />} 
              label="Terms And Conditions"
              onClick={() => handleNavigation("/dashboard")}
            />
            <SidebarItem 
              icon={<Lock />} 
              label="Privacy Policy"
              onClick={() => handleNavigation("/privacy-policy")}
            />
            <SidebarItem 
              icon={<IdCard />} 
              label="KYC & AML"
              onClick={() => handleNavigation("/kyc-aml")}
            />
            <SidebarItem
              icon={<LogOut />}
              label="Log Out"
              onClick={handleLogout}
            />
          </div>
        </div>
      </nav>
    </>
  );
};

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  hasArrow?: boolean;
  onClick?: () => void;
}

const SidebarItem = ({ icon, label, hasArrow, onClick }: SidebarItemProps) => {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center px-4 py-3 text-sm text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
    >
      <span className="w-4 h-4 mr-3">{icon}</span>
      <span className="flex-1 text-left">{label}</span>
      {hasArrow && <span className="text-xs">→</span>}
    </button>
  );
};

export default Sidebar;
