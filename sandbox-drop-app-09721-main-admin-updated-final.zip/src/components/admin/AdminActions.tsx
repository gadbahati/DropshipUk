import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const ADMIN_EMAIL = "Dropshiment.ecommerce@gmail.com";

const callFunction = async (fnName: string, payload: any) => {
  try {
    const res = await supabase.functions.invoke(fnName, {
      body: JSON.stringify(payload),
    });
    if ((res as any).status >= 400) {
      console.error("function error", res);
      return { error: true, res };
    }
    return { error: false, res };
  } catch (e) {
    console.error(e);
    return { error: true, e };
  }
};

const AdminActions = () => {
  const [pendingCounts, setPendingCounts] = useState({
    withdrawals: 0,
    verification: 0,
    activations: 0,
  });

  const fetchCounts = async () => {
    try {
      const { count: wCount } = await supabase
        .from("withdrawal_requests")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending");
      const { count: vCount } = await supabase
        .from("verification_payments")
        .select("id", { count: "exact", head: true })
        .eq("status", "paid");
      const { count: aCount } = await supabase
        .from("activation_payments")
        .select("id", { count: "exact", head: true })
        .eq("status", "paid");

      setPendingCounts({
        withdrawals: wCount || 0,
        verification: vCount || 0,
        activations: aCount || 0,
      });
    } catch (e) {
      console.error("fetchCounts error", e);
    }
  };

  useEffect(() => {
    fetchCounts();
    const chan = supabase
      .channel("admin-counts")
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawal_requests" }, fetchCounts)
      .on("postgres_changes", { event: "*", schema: "public", table: "verification_payments" }, fetchCounts)
      .on("postgres_changes", { event: "*", schema: "public", table: "activation_payments" }, fetchCounts)
      .subscribe();
    return () => {
      chan.unsubscribe();
    };
  }, []);

  const ensureAdmin = async () => {
    const { data: sessionData } = await supabase.auth.getSession();
    const email = sessionData?.data?.session?.user?.email;
    return email === ADMIN_EMAIL;
  };

  const handleApproveWithdrawals = async () => {
    if (!(await ensureAdmin())) {
      toast.error("Not authorized");
      return;
    }
    const { error, res } = await callFunction("approve-withdrawal", {});
    if (error) toast.error("Error calling function");
    else {
      toast.success("Approve withdrawal function called");
      fetchCounts();
    }
  };

  const handleApproveVerification = async () => {
    if (!(await ensureAdmin())) { toast.error("Not authorized"); return; }
    const { error } = await callFunction("approve-verification", {});
    if (error) toast.error("Error calling function");
    else { toast.success("Approve verification function called"); fetchCounts(); }
  };

  const handleApproveActivation = async () => {
    if (!(await ensureAdmin())) { toast.error("Not authorized"); return; }
    const { error } = await callFunction("approve-activation", {});
    if (error) toast.error("Error calling function");
    else { toast.success("Approve activation function called"); fetchCounts(); }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Admin Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div>Pending withdrawals: <strong>{pendingCounts.withdrawals}</strong></div>
          <div>Pending verifications: <strong>{pendingCounts.verification}</strong></div>
          <div>Pending activations: <strong>{pendingCounts.activations}</strong></div>

          <div className="flex flex-col sm:flex-row gap-2 mt-3">
            <Button onClick={handleApproveWithdrawals} className="w-full">Process Withdrawals</Button>
            <Button onClick={handleApproveVerification} className="w-full">Process Verifications</Button>
            <Button onClick={handleApproveActivation} className="w-full">Process Activations</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminActions;
